create definer = KanShan@`%` view detalis as
select `homework`.`trade`.`Cno`     AS `Cno`,
       `homework`.`trade`.`Tname`   AS `Tname`,
       `homework`.`goods`.`Gname`   AS `Gname`,
       `homework`.`goods`.`Gprice`  AS `Gprice`,
       `homework`.`trade`.`Tnumber` AS `Tnumber`
from `homework`.`trade`
         join `homework`.`goods`
where (`homework`.`trade`.`Tname` = `homework`.`goods`.`Gno`);

